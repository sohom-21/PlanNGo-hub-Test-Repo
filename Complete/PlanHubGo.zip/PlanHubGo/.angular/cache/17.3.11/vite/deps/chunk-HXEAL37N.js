// node_modules/.pnpm/ol@10.3.1/node_modules/ol/asserts.js
function assert(assertion, errorMessage) {
  if (!assertion) {
    throw new Error(errorMessage);
  }
}

export {
  assert
};
//# sourceMappingURL=chunk-HXEAL37N.js.map
