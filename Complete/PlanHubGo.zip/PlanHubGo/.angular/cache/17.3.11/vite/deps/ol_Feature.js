import {
  Feature_default,
  createStyleFunction
} from "./chunk-XRVESDHL.js";
import "./chunk-HXEAL37N.js";
import "./chunk-AJHGGXJK.js";
import "./chunk-NTOASQDC.js";
import "./chunk-YFRIKTX7.js";
export {
  createStyleFunction,
  Feature_default as default
};
//# sourceMappingURL=ol_Feature.js.map
