import {
  View_default,
  createCenterConstraint,
  createResolutionConstraint,
  createRotationConstraint,
  isNoopAnimation
} from "./chunk-JKIGIXOG.js";
import "./chunk-TOY66OVK.js";
import "./chunk-GPII5D2P.js";
import "./chunk-FY6CNAKC.js";
import "./chunk-VHE2Q6KG.js";
import "./chunk-6QY7KMHH.js";
import "./chunk-6SE5MGEN.js";
import "./chunk-3J7TX3BD.js";
import "./chunk-SP7PE42F.js";
import "./chunk-M6FSIOYI.js";
import "./chunk-5YOCZYRA.js";
import "./chunk-HXEAL37N.js";
import "./chunk-AJHGGXJK.js";
import "./chunk-NTOASQDC.js";
import "./chunk-YFRIKTX7.js";
export {
  createCenterConstraint,
  createResolutionConstraint,
  createRotationConstraint,
  View_default as default,
  isNoopAnimation
};
//# sourceMappingURL=ol_View.js.map
