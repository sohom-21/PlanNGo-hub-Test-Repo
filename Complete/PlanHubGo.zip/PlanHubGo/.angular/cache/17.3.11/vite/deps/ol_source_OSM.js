import {
  XYZ_default
} from "./chunk-5AZGYGUJ.js";
import "./chunk-35DR4KF7.js";
import "./chunk-FI4VKMZ4.js";
import "./chunk-MOMU4WPH.js";
import "./chunk-7H6PNUFL.js";
import "./chunk-3GY3OPAD.js";
import "./chunk-TOY66OVK.js";
import "./chunk-6SE5MGEN.js";
import "./chunk-3J7TX3BD.js";
import "./chunk-SP7PE42F.js";
import "./chunk-M6FSIOYI.js";
import "./chunk-5YOCZYRA.js";
import "./chunk-HXEAL37N.js";
import "./chunk-AJHGGXJK.js";
import "./chunk-NTOASQDC.js";
import "./chunk-YFRIKTX7.js";

// node_modules/.pnpm/ol@10.3.1/node_modules/ol/source/OSM.js
var ATTRIBUTION = '&#169; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors.';
var OSM = class extends XYZ_default {
  /**
   * @param {Options} [options] Open Street Map options.
   */
  constructor(options) {
    options = options || {};
    let attributions;
    if (options.attributions !== void 0) {
      attributions = options.attributions;
    } else {
      attributions = [ATTRIBUTION];
    }
    const crossOrigin = options.crossOrigin !== void 0 ? options.crossOrigin : "anonymous";
    const url = options.url !== void 0 ? options.url : "https://tile.openstreetmap.org/{z}/{x}/{y}.png";
    super({
      attributions,
      attributionsCollapsible: false,
      cacheSize: options.cacheSize,
      crossOrigin,
      interpolate: options.interpolate,
      maxZoom: options.maxZoom !== void 0 ? options.maxZoom : 19,
      reprojectionErrorThreshold: options.reprojectionErrorThreshold,
      tileLoadFunction: options.tileLoadFunction,
      transition: options.transition,
      url,
      wrapX: options.wrapX,
      zDirection: options.zDirection
    });
  }
};
var OSM_default = OSM;
export {
  ATTRIBUTION,
  OSM_default as default
};
//# sourceMappingURL=ol_source_OSM.js.map
