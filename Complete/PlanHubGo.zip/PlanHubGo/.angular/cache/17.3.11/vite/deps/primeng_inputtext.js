import {
  InputText,
  InputTextModule
} from "./chunk-CDL7RNEC.js";
import "./chunk-HMFWGVUT.js";
import "./chunk-NWXP5GR7.js";
import "./chunk-HMNCL6G5.js";
import "./chunk-XNRAG7MO.js";
import "./chunk-HCPDP34A.js";
import "./chunk-S65KPVXH.js";
import "./chunk-HVBD7MMJ.js";
import "./chunk-3RHARSHQ.js";
import "./chunk-YFRIKTX7.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
