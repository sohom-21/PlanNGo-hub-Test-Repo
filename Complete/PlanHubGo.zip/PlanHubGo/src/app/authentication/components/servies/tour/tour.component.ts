import { Component } from '@angular/core';

@Component({
  selector: 'app-tour',
  standalone: true,
  imports: [],
  templateUrl: './tour.component.html',
  styleUrl: './tour.component.css'
})
export class TourComponent {

}
