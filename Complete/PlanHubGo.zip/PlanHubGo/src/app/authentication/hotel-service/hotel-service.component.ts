import { Component } from '@angular/core';

@Component({
  selector: 'app-hotel-service',
  standalone: true,
  imports: [],
  templateUrl: './hotel-service.component.html',
  styleUrl: './hotel-service.component.css'
})
export class HotelServiceComponent {

}
