import { Component } from '@angular/core';

@Component({
  selector: 'app-tour-service',
  standalone: true,
  imports: [],
  templateUrl: './tour-service.component.html',
  styleUrl: './tour-service.component.css'
})
export class TourServiceComponent {

}
