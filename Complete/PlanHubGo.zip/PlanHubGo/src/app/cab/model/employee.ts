export interface Employee {
id: string;
         EmployeeName: string;
         EmployeeEmail: string;
         phone: number;
         employementType: string;
         DOB: string;
         Gender: string;
}