import { Component } from '@angular/core';

@Component({
  selector: 'app-add-service',
  standalone: true,
  imports: [],
  templateUrl: './add-service.component.html',
  styleUrl: './add-service.component.css'
})
export class AddServiceComponent {

}
