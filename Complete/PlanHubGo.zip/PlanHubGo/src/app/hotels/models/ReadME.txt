To run db.json server

npm install -g json-server
json-server --watch db.json