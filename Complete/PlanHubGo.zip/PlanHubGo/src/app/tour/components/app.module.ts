import { HttpClientModule } from '@angular/common/http';

import { NgModule } from '@angular/core'
import { AppComponent } from './app.component'

@NgModule({
  declarations: [
  ],
  imports: [
    // other modules
    AppComponent
  ],
  providers: []
})
export class AppModule { }
